"""
SYNTHETIC UKHSA DASHBOARD API CACHE - FOR PIPELINE TESTING ONLY. NOT REAL DATA.

Writes a cache of API responses that the reverse-analysis notebook reads exactly as it would read
real responses (same URL normalisation, same hash-named JSON files), so the whole pipeline - topic
discovery, pagination, onset parsing, geography harmonisation and every model - runs offline
(REV_OFFLINE=1) and can be checked against known truth.

Outcome counts are simulated on top of the REAL prescribing extract (the CID pipeline's cached BNF 5.1
extract), as negative-binomial counts per ICB and month with realistic national levels (UKHSA dashboard,
2025-26), seasonality and ICB size taken from prescribing volume. Planted effects, on log(items per
working day) deviations from each ICB's mean (elasticities):
  * E. coli COCA       <- urinary agents, lag 0, beta 0.40;  E. coli COHA <- urinary agents, lag 0, beta 0.20
  * C. difficile COCA  <- 4C group, lag 1, beta 0.60;        C. difficile COIA <- 4C group, lag 1, beta 0.30
  * MSSA COCA          <- flucloxacillin, lag 0, beta 0.30
  * P. aeruginosa (all onsets) <- fluoroquinolones, lag 0, beta 0.50
  * CDI treatment (oral vancomycin, fidaxomicin) RESPONDS to infection: in each ICB, those items in month t
                          are rescaled by (C. difficile cases in month t-1 / ICB mean) ** 0.8, and the modified
                          extract is written to <out-dir>/extract_bnf0501.csv.gz, which the notebook reads in
                          preference to data_cache/. R3 must call this pair "infections -> prescribing" while
                          the same C. difficile series carries the forward 4C effect.
  * Klebsiella spp., MRSA, and every hospital-onset (HOHA) series except P. aeruginosa: no effect (nulls)
  * Mycoplasma pneumoniae (national) <- macrolides, lag 0, beta 0.80
Decoys exercise discovery: an AMR "E-coli" topic without ICB data, a rate metric beside each count
metric, a positivity metric beside the Mycoplasma counts, no invasive group A strep topic at all, and
pagination with a "next" link that asks for format=api. The last month of MRSA is flagged as inside
the reporting-delay period.

SAFETY: the generator writes SYNTHETIC_DATA_DO_NOT_USE_FOR_RESULTS.txt into <out-dir>; the notebook detects
it, prints a warning and watermarks every figure. It refuses to overwrite an API cache that lacks the
marker (that would be a real download), unless --force is given. Run it in a COPY of your project folder.

Usage:
  python make_synthetic_ukhsa_test_data.py [--extract PATH] [--out-dir outputs_reverse]
      [--geography 2023|2026] [--start 202308] [--end 202512] [--strata labels|codes]
      [--supplement-from 202101] [--seed 7] [--effect-scale 1] [--force]
  --geography 2026  reports every month in the April 2026 configuration (36 ICBs; split ICBs divided
                    multinomially), which the notebook must harmonise into 32 units.
  --supplement-from writes <out-dir>/synthetic_supplement.csv with the months before --start (42-ICB
                    geography, long format) so that R4 becomes estimable via SUPPLEMENT_CSV.
  --effect-scale    multiplies every planted beta (5 makes the effects strong enough for R1 to detect).
"""
import argparse
import hashlib
import json
import os
import re
import shutil
from datetime import date, timedelta
from urllib.parse import quote, urlsplit, urlunsplit, parse_qsl, urlencode

import numpy as np
import pandas as pd

API_BASE = "https://api.ukhsa-dashboard.data.gov.uk"
THEME = "infectious_disease"
PAGE_SIZE = 365          # what the notebook requests
SERVE_PAGE = 100         # what this fake server returns per page, to exercise pagination


# ---- must match the notebook exactly -----------------------------------------------------------
def normalise_url(url, params=None):
    parts = urlsplit(url)
    q = dict(parse_qsl(parts.query, keep_blank_values=True))
    for k, v in (params or {}).items():
        q[str(k)] = str(v)
    q["format"] = "json"
    return urlunsplit((parts.scheme, parts.netloc, parts.path, urlencode(sorted(q.items())), ""))


def api_url(*parts):
    return API_BASE + "/" + "/".join(quote(str(p), safe="") for p in parts)


DRUG_RULES = [
    (r"CO-?AMOXICLAV|CLAVULAN", "Co-amoxiclav"),
    (r"CO-?TRIMOXAZOLE|SULFAMETHOXAZOLE|SULPHAMETHOXAZOLE", "Co-trimoxazole"),
    (r"\bAMOXICILLIN\b|\bAMOXYCILLIN\b", "Amoxicillin"),
    (r"PHENOXYMETHYLPENICILLIN|\bPENICILLIN V\b", "Phenoxymethylpenicillin"),
    (r"\bFLUCLOXACILLIN\b", "Flucloxacillin"),
    (r"\bPIVMECILLINAM\b", "Pivmecillinam"),
    (r"\bCEFALEXIN\b|\bCEPHALEXIN\b", "Cefalexin"),
    (r"\bCLARITHROMYCIN\b", "Clarithromycin"),
    (r"\bAZITHROMYCIN\b", "Azithromycin"),
    (r"\bERYTHROMYCIN\b", "Erythromycin"),
    (r"\bDOXYCYCLINE\b", "Doxycycline"),
    (r"\bCIPROFLOXACIN\b", "Ciprofloxacin"),
    (r"\bLEVOFLOXACIN\b", "Levofloxacin"),
    (r"\bTRIMETHOPRIM\b", "Trimethoprim"),
    (r"\bNITROFURANTOIN\b", "Nitrofurantoin"),
    (r"\bFOSFOMYCIN\b", "Fosfomycin"),
    (r"\bMETRONIDAZOLE\b", "Metronidazole"),
]
BUCKET_BY_PARAGRAPH = {"050112": "Other quinolones", "050102": "Other cephalosporins", "050103": "Other tetracyclines"}
BUCKET_BY_NAME = [(r"FLOXACIN|NALIDIXIC", "Other quinolones"), (r"\bCEF|\bCEPH", "Other cephalosporins"),
                  (r"CYCLINE\b", "Other tetracyclines")]
FORM_RULES = [
    ("parenteral", r"INJECTION|INFUSION|\bVIALS?\b|AMPOULES?|FOR SOLUTION FOR|FOR SUSPENSION FOR"),
    ("other_route", r"SUPPOSITOR|PESSAR|ENEMA|\bGEL\b|CREAM|OINTMENT|\bEYE\b|\bEAR\b|NEBUL|INHAL|"
                    r"IRRIGAT|VAGINAL|RECTAL|CUTANEOUS|\bPASTE\b|\bSPRAY\b|IMPLANT|\bPATCH"),
    ("oral_liquid", r"ORAL SUSPENSION|ORAL SOLUTION|SUSPENSION|SYRUP|ELIXIR|ORAL DROPS|LIQUID|"
                    r"MIXTURE|GRANULES|SACHETS?|ORAL POWDER|POWDER FOR ORAL|/\s*\d+(\.\d+)?\s*ML\b"),
    ("oral_solid", r"TABLETS?|CAPSULES?|CAPLETS?|\bTABS?\b|\bCAPS?\b|ORODISPERSIBLE|CHEWABLE|"
                   r"DISPERSIBLE|LOZENGES?"),
]


def assign_unit(chem, par):
    c = str(chem).upper()
    for pat, u in DRUG_RULES:
        if re.search(pat, c):
            return u
    if str(par) in BUCKET_BY_PARAGRAPH:
        return BUCKET_BY_PARAGRAPH[str(par)]
    for pat, u in BUCKET_BY_NAME:
        if re.search(pat, c):
            return u
    return "Other antibacterials"


def classify_form(p):
    p = str(p).upper()
    for f, pat in FORM_RULES:
        if re.search(pat, p):
            return f
    return "unknown"


GROUPS = {   # the exposures the planted effects use, defined as in the notebook
    "URINARY": ["Trimethoprim", "Nitrofurantoin", "Pivmecillinam", "Fosfomycin"],
    "FLUCLOX": ["Flucloxacillin"],
    "FQ": ["Ciprofloxacin", "Levofloxacin", "Other quinolones"],
    "4C": ["Co-amoxiclav", "Cefalexin", "Other cephalosporins", "Ciprofloxacin", "Levofloxacin",
           "Other quinolones", "@CLINDAMYCIN"],
    "MACROLIDES": ["Clarithromycin", "Erythromycin", "Azithromycin"],
    "CDITX": ["@CDITX"],
}

# ---- geography (ONS April 2023 and April 2026 code lists) --------------------------------------
ICB_2023 = [
    ("E54000008", "QYG", "NHS Cheshire and Merseyside Integrated Care Board"),
    ("E54000010", "QNC", "NHS Staffordshire and Stoke-on-Trent Integrated Care Board"),
    ("E54000011", "QOC", "NHS Shropshire, Telford and Wrekin Integrated Care Board"),
    ("E54000013", "QJM", "NHS Lincolnshire Integrated Care Board"),
    ("E54000015", "QK1", "NHS Leicester, Leicestershire and Rutland Integrated Care Board"),
    ("E54000018", "QWU", "NHS Coventry and Warwickshire Integrated Care Board"),
    ("E54000019", "QGH", "NHS Herefordshire and Worcestershire Integrated Care Board"),
    ("E54000022", "QMM", "NHS Norfolk and Waveney Integrated Care Board"),
    ("E54000023", "QJG", "NHS Suffolk and North East Essex Integrated Care Board"),
    ("E54000024", "QHG", "NHS Bedfordshire, Luton and Milton Keynes Integrated Care Board"),
    ("E54000025", "QM7", "NHS Hertfordshire and West Essex Integrated Care Board"),
    ("E54000026", "QH8", "NHS Mid and South Essex Integrated Care Board"),
    ("E54000027", "QRV", "NHS North West London Integrated Care Board"),
    ("E54000028", "QMJ", "NHS North Central London Integrated Care Board"),
    ("E54000029", "QMF", "NHS North East London Integrated Care Board"),
    ("E54000030", "QKK", "NHS South East London Integrated Care Board"),
    ("E54000031", "QWE", "NHS South West London Integrated Care Board"),
    ("E54000032", "QKS", "NHS Kent and Medway Integrated Care Board"),
    ("E54000034", "QNQ", "NHS Frimley Integrated Care Board"),
    ("E54000036", "QT6", "NHS Cornwall and the Isles of Scilly Integrated Care Board"),
    ("E54000037", "QJK", "NHS Devon Integrated Care Board"),
    ("E54000038", "QSL", "NHS Somerset Integrated Care Board"),
    ("E54000039", "QUY", "NHS Bristol, North Somerset and South Gloucestershire Integrated Care Board"),
    ("E54000040", "QOX", "NHS Bath and North East Somerset, Swindon and Wiltshire Integrated Care Board"),
    ("E54000041", "QVV", "NHS Dorset Integrated Care Board"),
    ("E54000042", "QRL", "NHS Hampshire and Isle of Wight Integrated Care Board"),
    ("E54000043", "QR1", "NHS Gloucestershire Integrated Care Board"),
    ("E54000044", "QU9", "NHS Buckinghamshire, Oxfordshire and Berkshire West Integrated Care Board"),
    ("E54000048", "QE1", "NHS Lancashire and South Cumbria Integrated Care Board"),
    ("E54000050", "QHM", "NHS North East and North Cumbria Integrated Care Board"),
    ("E54000051", "QOQ", "NHS Humber and North Yorkshire Integrated Care Board"),
    ("E54000054", "QWO", "NHS West Yorkshire Integrated Care Board"),
    ("E54000055", "QHL", "NHS Birmingham and Solihull Integrated Care Board"),
    ("E54000056", "QUE", "NHS Cambridgeshire and Peterborough Integrated Care Board"),
    ("E54000057", "QOP", "NHS Greater Manchester Integrated Care Board"),
    ("E54000058", "QJ2", "NHS Derby and Derbyshire Integrated Care Board"),
    ("E54000059", "QPM", "NHS Northamptonshire Integrated Care Board"),
    ("E54000060", "QT1", "NHS Nottingham and Nottinghamshire Integrated Care Board"),
    ("E54000061", "QF7", "NHS South Yorkshire Integrated Care Board"),
    ("E54000062", "QUA", "NHS Black Country Integrated Care Board"),
    ("E54000063", "QXU", "NHS Surrey Heartlands Integrated Care Board"),
    ("E54000064", "QNX", "NHS Sussex Integrated Care Board"),
]
# new 2026 ICB -> {old ICB: share of the old ICB's territory it received}
ICB_2026_NEW = [
    ("E54000065", "NHS Central East Integrated Care Board", {"QHG": 1.0, "QUE": 1.0, "QM7": 0.75}),
    ("E54000066", "NHS Essex Integrated Care Board", {"QH8": 1.0, "QM7": 0.25, "QJG": 0.40}),
    ("E54000067", "NHS Hampshire and Isle of Wight Integrated Care Board", {"QRL": 1.0, "QNQ": 0.20}),
    ("E54000068", "NHS Norfolk and Suffolk Integrated Care Board", {"QMM": 1.0, "QJG": 0.60}),
    ("E54000069", "NHS Surrey and Sussex Integrated Care Board", {"QXU": 1.0, "QNX": 1.0, "QNQ": 0.30}),
    ("E54000070", "NHS Thames Valley Integrated Care Board", {"QU9": 1.0, "QNQ": 0.50}),
    ("E54000071", "NHS West and North London Integrated Care Board", {"QRV": 1.0, "QMJ": 1.0}),
]

# ---- outcome model ------------------------------------------------------------------------------
TOPICS = {   # organism -> (sub_theme, topic, metric, national monthly mean by onset)
    "ECOLI": ("bloodstream_infection", "E-coli", "e-coli_cases_countsByOnsetTypeByMonth",
              {"COCA": 2500, "COHA": 560, "HOHA": 690, "UNKNOWN": 3}),
    "KLEB": ("bloodstream_infection", "Klebsiella-spp", "klebsiella-spp_cases_countsByOnsetTypeByMonth",
             {"COCA": 650, "COHA": 180, "HOHA": 340, "UNKNOWN": 1}),
    "PSA": ("bloodstream_infection", "Pseudomonas-aeruginosa",
            "pseudomonas-aeruginosa_cases_countsByOnsetTypeByMonth", {"COCA": 150, "COHA": 70, "HOHA": 130}),
    "MSSA": ("bloodstream_infection", "MSSA", "MSSA_cases_countsByOnsetTypeByMonth",
             {"COCA": 520, "COHA": 200, "HOHA": 400, "UNKNOWN": 2}),
    "MRSA": ("bloodstream_infection", "MRSA", "MRSA_cases_countsByOnsetTypeByMonth",
             {"COCA": 30, "COHA": 15, "HOHA": 30}),
    "CDI": ("gastrointestinal", "C-difficile", "c-difficile_cases_countsByOnsetTypeByMonth",
            {"COCA": 420, "COHA": 250, "COIA": 155, "HOHA": 600, "UNKNOWN": 1}),
}
SEASON = {"ECOLI": (0.10, 8), "KLEB": (0.10, 8), "PSA": (0.08, 8), "MSSA": (0.04, 8), "MRSA": (0.0, 1),
          "CDI": (0.05, 1)}           # amplitude on the log scale, peak month
TREND = {"ECOLI": 0.01, "KLEB": 0.02, "PSA": 0.0, "MSSA": 0.01, "MRSA": -0.02, "CDI": 0.02}   # per year
PLANTED = [  # (organism, onset or "*" for all, exposure, lag in months, beta)
    ("ECOLI", "COCA", "URINARY", 0, 0.40), ("ECOLI", "COHA", "URINARY", 0, 0.20),
    ("CDI", "COCA", "4C", 1, 0.60), ("CDI", "COIA", "4C", 1, 0.30),
    ("MSSA", "COCA", "FLUCLOX", 0, 0.30),
    ("PSA", "*", "FQ", 0, 0.50),
]
TREATMENT_RESPONSE = 0.8   # CDI-treatment items in month t scale with (C. difficile cases in month t-1) ** 0.8
LABELS = {"TOTAL": "Total cases", "COCA": "Community-onset, community-associated",
          "COHA": "Community-onset, healthcare-associated", "COIA": "Community-onset, indeterminate-association",
          "HOHA": "Hospital-onset, healthcare-associated", "UNKNOWN": "Unknown", "NOINFO": "No information"}
CODES = {"TOTAL": "total", "COCA": "COCA", "COHA": "COHA", "COIA": "COIA", "HOHA": "HOHA", "UNKNOWN": "unknown",
         "NOINFO": "no_information"}

BH = {date(2021, 1, 1), date(2021, 4, 2), date(2021, 4, 5), date(2021, 5, 3), date(2021, 5, 31),
      date(2021, 8, 30), date(2021, 12, 27), date(2021, 12, 28), date(2022, 1, 3), date(2022, 4, 15),
      date(2022, 4, 18), date(2022, 5, 2), date(2022, 6, 2), date(2022, 6, 3), date(2022, 8, 29),
      date(2022, 9, 19), date(2022, 12, 26), date(2022, 12, 27), date(2023, 1, 2), date(2023, 4, 7),
      date(2023, 4, 10), date(2023, 5, 1), date(2023, 5, 8), date(2023, 5, 29), date(2023, 8, 28),
      date(2023, 12, 25), date(2023, 12, 26), date(2024, 1, 1), date(2024, 3, 29), date(2024, 4, 1),
      date(2024, 5, 6), date(2024, 5, 27), date(2024, 8, 26), date(2024, 12, 25), date(2024, 12, 26),
      date(2025, 1, 1), date(2025, 4, 18), date(2025, 4, 21), date(2025, 5, 5), date(2025, 5, 26),
      date(2025, 8, 25), date(2025, 12, 25), date(2025, 12, 26), date(2026, 1, 1), date(2026, 4, 3),
      date(2026, 4, 6), date(2026, 5, 4), date(2026, 5, 25), date(2026, 8, 31), date(2026, 12, 25),
      date(2026, 12, 28)}


def wd(ym):
    y, m = divmod(ym, 100)
    d, n = date(y, m, 1), 0
    while d.month == m:
        n += (d.weekday() < 5 and d not in BH)
        d += timedelta(days=1)
    return n


def mdays(ym):
    y, m = divmod(ym, 100)
    return (date(y + (m == 12), m % 12 + 1, 1) - date(y, m, 1)).days


def ym_range(a, b):
    out, y, m = [], a // 100, a % 100
    while y * 100 + m <= b:
        out.append(y * 100 + m)
        y, m = (y + 1, 1) if m == 12 else (y, m + 1)
    return out


class Cache:
    def __init__(self, folder):
        self.folder = folder
        if os.path.isdir(folder):
            shutil.rmtree(folder)
        os.makedirs(folder)
        self.n = 0

    def put(self, url, payload, params=None):
        full = normalise_url(url, params)
        with open(os.path.join(self.folder, hashlib.sha1(full.encode("utf-8")).hexdigest() + ".json"), "w") as fh:
            json.dump({"url": full, "status": 200, "payload": payload}, fh)
        self.n += 1

    def listing(self, parts, names):
        self.put(api_url(*parts), [{"name": n, "link": api_url(*parts, n)} for n in names])

    def series(self, parts, records):
        url = api_url(*parts)
        pages = [records[i:i + SERVE_PAGE] for i in range(0, len(records), SERVE_PAGE)] or [[]]
        for i, chunk in enumerate(pages, 1):
            nxt = (url + "?page=%d&page_size=%d&format=api" % (i + 1, PAGE_SIZE)) if i < len(pages) else None
            payload = {"count": len(records), "next": nxt, "previous": None, "results": chunk}
            if i == 1:
                self.put(url, payload, {"page_size": PAGE_SIZE})
            else:
                self.put(url + "?page=%d&page_size=%d&format=api" % (i, PAGE_SIZE), payload)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--extract", default=None)
    ap.add_argument("--out-dir", default="outputs_reverse")
    ap.add_argument("--geography", default="2023", choices=["2023", "2026"])
    ap.add_argument("--start", type=int, default=202308)
    ap.add_argument("--end", type=int, default=202512)
    ap.add_argument("--strata", default="labels", choices=["labels", "codes"])
    ap.add_argument("--supplement-from", type=int, default=None)
    ap.add_argument("--seed", type=int, default=7)
    ap.add_argument("--force", action="store_true", help="overwrite a cache that lacks the synthetic marker")
    ap.add_argument("--effect-scale", type=float, default=1.0,
                    help="multiply every planted beta (e.g. 5 to check that R1 detects strong signals)")
    a = ap.parse_args()
    rng = np.random.default_rng(a.seed)

    path = a.extract or next((p for p in ["outputs_antibacterials/extract_bnf0501.csv.gz",
                                          "data_cache/extract_bnf0501.csv.gz"] if os.path.exists(p)), None)
    if not path:
        raise SystemExit("Cannot find extract_bnf0501.csv.gz - pass --extract")
    marker = os.path.join(a.out_dir, "SYNTHETIC_DATA_DO_NOT_USE_FOR_RESULTS.txt")
    if os.path.isdir(os.path.join(a.out_dir, "ukhsa_api_cache")) and not os.path.exists(marker) and not a.force:
        raise SystemExit("%s already holds an API cache without the synthetic marker - probably a REAL download. "
                         "Refusing to overwrite it; use another --out-dir (or --force)." % a.out_dir)
    os.makedirs(a.out_dir, exist_ok=True)
    with open(marker, "w") as fh:
        fh.write("Everything in this folder was produced from SYNTHETIC outcome data by make_synthetic_ukhsa_test_data.py.\n"
                 "It exists to test the pipeline. None of it is a result.\n")
    raw = pd.read_csv(path, dtype={"ORG_CODE": str, "ORG_NAME": str, "BNF_CODE": str, "CHEMICAL": str,
                                   "PRESENTATION": str})
    ext = raw.copy()
    combos = ext[["BNF_CODE", "CHEMICAL", "PRESENTATION"]].drop_duplicates()
    combos["UNIT"] = [assign_unit(c, b[:6]) for c, b in zip(combos.CHEMICAL, combos.BNF_CODE)]
    combos["FORM"] = combos.PRESENTATION.map(classify_form)
    up = combos.CHEMICAL.str.upper()
    combos.loc[up.str.contains(r"\bCLINDAMYCIN\b"), "UNIT"] = "@CLINDAMYCIN"
    combos.loc[up.str.contains(r"\bVANCOMYCIN\b|\bFIDAXOMICIN\b"), "UNIT"] = "@CDITX"
    ext = ext.merge(combos, on=["BNF_CODE", "CHEMICAL", "PRESENTATION"])
    ext = ext[ext.FORM.isin(["oral_solid", "oral_liquid"])]
    months_p = sorted(ext.YEAR_MONTH.unique())
    icbs = [ods for _, ods, _ in ICB_2023]
    idx = pd.MultiIndex.from_product([icbs, months_p], names=["ORG_CODE", "YEAR_MONTH"])
    X = {}
    for gname, units in GROUPS.items():
        s = ext[ext.UNIT.isin(units)].groupby(["ORG_CODE", "YEAR_MONTH"]).ITEMS.sum().reindex(idx).fillna(0)
        lx = np.log((s + 0.5) / s.index.get_level_values(1).map(wd).values)
        X[gname] = (lx - lx.groupby(level=0).transform("mean")).to_dict()   # deviation from the ICB's mean
    size = ext.groupby("ORG_CODE").ITEMS.sum().reindex(icbs)
    w = size / size.sum()

    first = min(a.start, a.supplement_from or a.start)
    months = ym_range(first, a.end)
    yrs = {ym: (ym // 100 - 2023) + ((ym % 100) - 1) / 12 for ym in months}

    def xval(g, icb, ym, lag):
        y, m = divmod(ym, 100)
        t = y * 12 + m - 1 - lag
        key = (icb, (t // 12) * 100 + t % 12 + 1)
        return float(X[g].get(key, 0.0))   # 0 outside the prescribing months

    rows, re_icb = [], {(o, i): rng.normal(0, 0.10) for o in TOPICS for i in icbs}
    for org, (_, _, _, levels) in TOPICS.items():
        amp, peak = SEASON[org]
        for onset, nat in levels.items():
            r = 30.0 if nat >= 100 else 60.0
            for icb in icbs:
                for ym in months:
                    mu = nat * w[icb] * mdays(ym) / 30.4375 * np.exp(
                        amp * np.cos(2 * np.pi * ((ym % 100) - peak) / 12) + TREND[org] * yrs[ym] + re_icb[(org, icb)])
                    for (po, pon, g, lag, beta) in PLANTED:
                        if po == org and (pon == onset or pon == "*"):
                            mu *= np.exp(a.effect_scale * beta * xval(g, icb, ym, lag))
                    lam = rng.gamma(r, mu / r)
                    rows.append((org, icb, ym, onset, int(rng.poisson(lam))))
    sim = pd.DataFrame(rows, columns=["ORG", "ICB", "YEAR_MONTH", "ONSET", "CASES"])

    # CDI treatment responds to C. difficile one month later (the causal order R3 should recover)
    cdi = sim[sim.ORG == "CDI"].groupby(["ICB", "YEAR_MONTH"]).CASES.sum()
    rel = (cdi + 1) / (cdi.groupby(level=0).transform("mean") + 1)
    nxt = {ym: (ym + 1 if ym % 100 < 12 else (ym // 100 + 1) * 100 + 1) for ym in months}
    factor = {(icb, nxt[ym]): float(v) ** TREATMENT_RESPONSE for (icb, ym), v in rel.items()}
    is_tx = raw.CHEMICAL.str.upper().str.contains(r"\bVANCOMYCIN\b|\bFIDAXOMICIN\b", regex=True)
    f = np.array([factor.get((o, ym), 1.0) for o, ym in zip(raw.ORG_CODE[is_tx], raw.YEAR_MONTH[is_tx])])
    raw.loc[is_tx, "ITEMS"] = np.round(raw.loc[is_tx, "ITEMS"].to_numpy() * f).astype(int)
    raw.loc[is_tx, "QUANTITY"] = raw.loc[is_tx, "QUANTITY"].to_numpy() * f
    raw.to_csv(os.path.join(a.out_dir, "extract_bnf0501.csv.gz"), index=False, compression="gzip")

    # geography of the reported data
    if a.geography == "2023":
        rep = sim.merge(pd.DataFrame(ICB_2023, columns=["GEO_CODE", "ICB", "GEO_NAME"]), on="ICB")
    else:
        moved = {}
        for code, name, parts in ICB_2026_NEW:
            for old, frac in parts.items():
                moved.setdefault(old, []).append((code, name, frac))
        out = []
        for (org, icb, ym, onset), c in sim.set_index(["ORG", "ICB", "YEAR_MONTH", "ONSET"]).CASES.items():
            if icb in moved:
                dest = moved[icb]
                fr = np.array([d[2] for d in dest])
                for (code, name, _), k in zip(dest, rng.multinomial(c, fr / fr.sum())):
                    out.append((org, code, name, ym, onset, int(k)))
            else:
                code, _, name = next(t for t in ICB_2023 if t[1] == icb)
                out.append((org, code, name, ym, onset, int(c)))
        rep = (pd.DataFrame(out, columns=["ORG", "GEO_CODE", "GEO_NAME", "YEAR_MONTH", "ONSET", "CASES"])
               .groupby(["ORG", "GEO_CODE", "GEO_NAME", "YEAR_MONTH", "ONSET"], as_index=False).CASES.sum())

    folder = os.path.join(a.out_dir, "ukhsa_api_cache")
    cache = Cache(folder)
    lab = LABELS if a.strata == "labels" else CODES
    subs = ["antimicrobial_resistance", "bloodstream_infection", "gastrointestinal", "respiratory"]
    cache.listing(("themes", THEME, "sub_themes"), subs)
    cache.listing(("themes", THEME, "sub_themes", "antimicrobial_resistance", "topics"), ["E-coli", "K-pneumoniae"])
    cache.listing(("themes", THEME, "sub_themes", "bloodstream_infection", "topics"),
                  ["E-coli", "Klebsiella-spp", "MRSA", "MSSA", "Pseudomonas-aeruginosa"])
    cache.listing(("themes", THEME, "sub_themes", "gastrointestinal", "topics"), ["C-difficile"])
    cache.listing(("themes", THEME, "sub_themes", "respiratory", "topics"), ["COVID-19", "mycoplasma"])
    for t in ("E-coli", "K-pneumoniae"):        # decoy: AMR topics with national data only
        cache.listing(("themes", THEME, "sub_themes", "antimicrobial_resistance", "topics", t, "geography_types"),
                      ["Nation"])
    cache.listing(("themes", THEME, "sub_themes", "respiratory", "topics", "COVID-19", "geography_types"), ["Nation"])
    cache.listing(("themes", THEME, "sub_themes", "respiratory", "topics", "COVID-19", "geography_types", "Nation",
                   "geographies"), ["England"])
    cache.listing(("themes", THEME, "sub_themes", "respiratory", "topics", "COVID-19", "geography_types", "Nation",
                   "geographies", "England", "metrics"), ["COVID-19_cases_casesByDay"])
    gtypes = ["Integrated Care Board", "Nation", "NHS Region", "NHS Trust", "Sub-Integrated Care Board", "UKHSA Region"]
    api_part = rep[rep.YEAR_MONTH >= a.start]
    for org, (sub, topic, metric, levels) in TOPICS.items():
        base = ("themes", THEME, "sub_themes", sub, "topics", topic)
        cache.listing(base + ("geography_types",), gtypes)
        d = api_part[api_part.ORG == org]
        geos = sorted(d.GEO_NAME.unique())
        cache.listing(base + ("geography_types", "Integrated Care Board", "geographies"), geos)
        cache.listing(base + ("geography_types", "Integrated Care Board", "geographies", geos[0], "metrics"),
                      [metric.replace("counts", "rates"), metric])
        last = d.YEAR_MONTH.max()
        for gname, gd in d.groupby("GEO_NAME"):
            recs = []
            for (code, ym), cell in gd.groupby(["GEO_CODE", "YEAR_MONTH"]):
                vals = dict(zip(cell.ONSET, cell.CASES))
                vals["TOTAL"] = int(sum(vals.values()))
                vals["NOINFO"] = 0
                for onset, v in vals.items():
                    recs.append(dict(theme=THEME, sub_theme=sub, topic=topic, geography_type="Integrated Care Board",
                                     geography=gname, geography_code=code, metric=metric, metric_group="cases",
                                     stratum=lab[onset], sex="all", age="all", year=ym // 100, month=ym % 100,
                                     epiweek=None, date="%d-%02d-01" % (ym // 100, ym % 100), metric_value=float(v),
                                     in_reporting_delay_period=bool(org == "MRSA" and ym == last)))
            cache.series(base + ("geography_types", "Integrated Care Board", "geographies", gname, "metrics", metric),
                         recs)

    # national Mycoplasma pneumoniae, March 2013 onwards; macrolide link where prescribing exists
    mac = ext[ext.UNIT.isin(GROUPS["MACROLIDES"])].groupby("YEAR_MONTH").ITEMS.sum()
    lmac = np.log(mac / mac.index.map(wd).values)
    lmac = lmac - lmac[lmac.index >= 202108].mean()
    nat_months = ym_range(201303, a.end)
    recs = []
    for ym in nat_months:
        mu = 40 * np.exp(0.35 * np.cos(2 * np.pi * ((ym % 100) - 12) / 12))
        if 202004 <= ym <= 202106:
            mu *= 0.05     # pandemic collapse, kept BEFORE the analysis window so the planted beta is recoverable;
                           # in real data the 2021-23 rebound overlaps the window (see notebook R5 caveat)
        if ym in lmac.index and ym >= 202108:
            mu *= np.exp(0.80 * lmac[ym])
        v = int(rng.poisson(rng.gamma(40, mu / 40)))
        for age, frac in [("all", 1.0), ("00-04", 0.2), ("05-14", 0.3), ("15-44", 0.35), ("45+", 0.15)]:
            recs.append(dict(theme=THEME, sub_theme="respiratory", topic="mycoplasma", geography_type="Nation",
                             geography="England", geography_code="E92000001", metric="mycoplasma_testing_byAgeGroup",
                             metric_group="testing", stratum="default", sex="all", age=age, year=ym // 100,
                             month=ym % 100, epiweek=None, date="%d-%02d-01" % (ym // 100, ym % 100),
                             metric_value=float(round(v * frac)), in_reporting_delay_period=False))
    mb = ("themes", THEME, "sub_themes", "respiratory", "topics", "mycoplasma")
    cache.listing(mb + ("geography_types",), ["Nation"])
    cache.listing(mb + ("geography_types", "Nation", "geographies"), ["England"])
    cache.listing(mb + ("geography_types", "Nation", "geographies", "England", "metrics"),
                  ["mycoplasma_testing_positivityByMonth", "mycoplasma_testing_byAgeGroup"])
    cache.series(mb + ("geography_types", "Nation", "geographies", "England", "metrics", "mycoplasma_testing_byAgeGroup"),
                 recs)

    truth = dict(note="SYNTHETIC - planted effects on log(items per working day) deviations from each ICB's mean",
                 effect_scale=a.effect_scale,
                 planted=[dict(org=o, onset=n, exposure=g, lag=l, beta=b * a.effect_scale) for o, n, g, l, b in PLANTED],
                 treatment_response=dict(exposure="CDITX", follows="CDI, all onsets", lag=1, power=TREATMENT_RESPONSE),
                 nulls=["KLEB all onsets", "MRSA all onsets", "HOHA of ECOLI, CDI, MSSA, KLEB, MRSA"],
                 mycoplasma=dict(exposure="MACROLIDES", lag=0, beta=0.80), geography=a.geography,
                 api_months=[a.start, a.end], supplement_from=a.supplement_from)
    with open(os.path.join(a.out_dir, "synthetic_truth.json"), "w") as fh:
        json.dump(truth, fh, indent=2)

    if a.supplement_from:
        sup = sim[sim.YEAR_MONTH < a.start].copy()
        names = {"ECOLI": "E. coli", "KLEB": "Klebsiella spp.", "PSA": "P. aeruginosa", "MSSA": "MSSA",
                 "MRSA": "MRSA", "CDI": "C. difficile"}
        sup = pd.DataFrame({"ods_code": sup.ICB, "year_month": sup.YEAR_MONTH, "organism": sup.ORG.map(names),
                            "onset": sup.ONSET, "cases": sup.CASES})
        sup.to_csv(os.path.join(a.out_dir, "synthetic_supplement.csv"), index=False)
        print("supplement: %d rows, %d-%d" % (len(sup), sup.year_month.min(), sup.year_month.max()))
    print("SYNTHETIC cache written: %d responses in %s (geography %s, strata as %s, API months %d-%d)" %
          (cache.n, folder, a.geography, a.strata, a.start, a.end))


if __name__ == "__main__":
    main()
