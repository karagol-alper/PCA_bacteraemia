# Reverse analysis: antibacterial prescribing → bacterial infection burden

Companion to `CID_antibacterial_prescribing_analysis.ipynb`. The CID pipeline treats prescribing as the
outcome of policy and supply shocks. This one reverses the arrow: prescribing (NHSBSA PCA, ICB × month)
is the predictor, and monthly laboratory-confirmed infections (UKHSA mandatory surveillance of *E. coli*,
*Klebsiella* spp., *P. aeruginosa*, MSSA and MRSA bacteraemia, and *C. difficile*) are the outcome.

    reverse_prescribing_to_bacteria.ipynb    the pipeline (33 cells)
    make_synthetic_ukhsa_test_data.py        synthetic outcome data with planted effects, for testing
    README_reverse_analysis.md               this file

| Aim | Question | Design |
|---|---|---|
| R1 | Does prescribing improve *out-of-sample* prediction of infections? | rolling-origin nowcast/forecast vs a unit + season + trend baseline |
| R2 | Which agents track which organism, at what lag? | Poisson fixed effects (ICB + month), distributed lags; 6 pre-specified pairs + BH-FDR grid; lead placebo |
| R3 | Which comes first? | bidirectional panel Granger, with a built-in check of known direction |
| R4 | Did infections change where the MHRA fluoroquinolone restriction bit hardest? | the CID ICB-intensity design reversed (reduced form + Wald IV) |
| R5 | Positive control | national *Mycoplasma pneumoniae* vs macrolide and tetracycline prescribing; invasive group A streptococcal infection vs amoxicillin and penicillin V |

## Running it

1. Put the notebook in the Drive folder that holds the CID work (`/content/drive/MyDrive/KCL/Drug/`). It
   needs the prescribing extract: raw `pca_*.csv` files in `DATA_DIR`, **or** the cached
   `outputs_antibacterials/extract_bnf0501.csv.gz` / `data_cache/extract_bnf0501.csv.gz` from your zip.
2. Run all cells. The first run makes about 300 requests to the UKHSA data dashboard API (1–3 minutes)
   and caches every response in `outputs_reverse/ukhsa_api_cache/`; re-runs are offline. On a two-core
   machine (a free Colab instance has two) with current library versions, the analysis then takes about
   5 minutes with API data alone and about 13 minutes with supplementary history, most of it bootstrap
   replications. `ABX_FAST_MODE=1` cuts this to a few minutes for testing.
3. Results go to `outputs_reverse/` (CSV tables, `all_tables_reverse.xlsx`, figures as PNG 300 dpi + PDF,
   `results_summary_reverse.txt`) and `outputs_reverse.zip` (without the API cache).
4. **Check `r0_outcome_download_audit.csv` and `r0_geography_harmonisation.csv` first.** They show what the
   API actually returned (topics, metric names, onset strata, months) and how ICBs were matched.

Settings in the configuration cell: `SUPPLEMENT_CSV` (earlier outcome months, see below),
`MANUAL_GEO_MAP`, `ALLOW_UNMATCHED_UNITS`, `HYPOTHESES`. Environment variables: `ABX_FAST_MODE=1` (fewer
replications, testing only), `REV_OFFLINE=1` (cache only, never touch the network), `REV_SUPPLEMENT_CSV`.

## Changes after the first real-data run (9 October 2026)

The first run on real API data showed two features of the API that its documentation does not mention.
Both inflated the outcome counts, and the pipeline now handles both:

* **Duplicated onset labels.** From February 2024 to January 2025 the API carries every onset category
  under two spellings ("community associated" and "community-associated"), as two releases of the same
  data: 9,576 duplicated ICB-month-category cells, of which 9,276 are identical, 268 differ by one or two
  cases and 32 by 3 to 14. Summing them doubled the onset counts in those months. Labels are now compared
  ignoring case and punctuation, only the spelling in current use is kept, and the run halts if onset
  categories differ from the published total by more than 2% in more than 1% of geography-months.
* **Both ICB configurations at once.** From May 2025 to March 2026 the API reports the six ICBs created
  in April 2026 alongside the ICBs they replaced. Summing everything counted those patients twice, merged
  12 ICBs into three spurious clusters and set 318 unit-months to missing. A new ICB is now dropped in any
  month in which all of its predecessors report (64 ICB-months), and a unit-month counts only if its
  territory is covered exactly once.
* **Weekly series** (iGAS, used in R5) are now spread over their seven days before being summed into
  calendar months, so months with five week-start dates are not inflated.
* **Prediction-skill intervals no longer depend on the pandas version** (11 October 2026). Each skill
  bootstrap is seeded from a text label that included the forecast horizon; pandas before 3.0 returns it
  as a NumPy integer, which changed the label and so the intervals. The horizon is now converted to a
  plain integer. Point estimates were never affected. The boosted-trees benchmark still varies with the
  scikit-learn version.

After the fixes all 42 ICBs are complete in every month of the window, the onset categories sum exactly
to the published totals, and the sum over ICBs is within 0.0–0.9% of England totals published by UKHSA
(`table_m_s2_validation.csv`, written by the new Section 12b with the manuscript's other descriptive
tables). Re-run the notebook on your cached download to get the corrected results; hypotheses and models
are unchanged.

### Adding outcome history before August 2023 (needed for R4)

The dashboard API holds these series only from December 2023 (October 2026 download), which gives 25
months that overlap PCA to December 2025. UKHSA's accredited monthly tables on GOV.UK ("MRSA, MSSA, Gram-negative bacteraemia and
CDI: monthly data", one collection per financial year) go back further. Assemble them into one long CSV
with columns for geography (ODS code such as `QE1`, ONS code such as `E54000048`, or ICB name), month
(`year_month` such as `202207`, or a date), organism, optional onset type, and count. Then set
`SUPPLEMENT_CSV`. Section 4b of the notebook gives the accepted column names. Where both sources cover a
unit and month, the API wins, and the agreement between them is printed.

## Testing without real outcome data

Run this in a **copy** of the project folder; the generator refuses to overwrite a real API cache.

    python make_synthetic_ukhsa_test_data.py
    python make_synthetic_ukhsa_test_data.py --geography 2026 --strata codes --supplement-from 202101

Then run the notebook with `REV_OFFLINE=1` (and, for the second form,
`REV_SUPPLEMENT_CSV=outputs_reverse/synthetic_supplement.csv`). The generator writes outcomes on top of
the real prescribing extract, in exactly the form the API client caches, so discovery, pagination,
parsing, geography matching and every model run as they would on real data. Planted effects are listed in
its header and in `outputs_reverse/synthetic_truth.json`. A marker file makes the notebook print a warning,
watermark every figure "SYNTHETIC TEST DATA" and flag the results summary.

## What was verified, and what was not

The sandbox used to build this could not reach the UKHSA API, so the **live API was not called**. The
client was written against UKHSA's API documentation, the `ukhsadatR` wrapper and the dashboard pages,
which confirmed the metric names (`…_cases_countsByOnsetTypeByMonth`), the "Integrated Care Board" area
type, the record fields and the pagination. Two things could not be confirmed and are handled
defensively, halting with a clear message if wrong: the exact `stratum` labels for onset type, and which
ICB configuration the API uses for historical months. The first real-data run settled both, and showed
two further problems that are now fixed (see "Changes after the first real-data run" above).

Everything else was run end to end:

* **Prescribing** reproduces the CID pipeline exactly: 176,879,270 items, 42 ICBs, 60 months.
* **The notebook executes with zero errors** under nbconvert. Tested configurations: (a) 42-ICB geography,
  dashboard labels, API months only; (b) the April 2026 36-ICB geography, abbreviated strata codes, plus a
  42-ICB supplement from 2021, which harmonises to 32 units (3 clusters) over 53 months; (c) both of these
  at full replication counts.
* **The API client** passed tests on a mock built from the documented schema: it skipped decoy topics,
  followed paginated `next` links (overriding `format=api`), dropped reporting-delay months, parsed both
  label and code strata, and replayed every response offline.
* **Library versions.** The pipeline was run under two library sets: the one the tests below were first
  run with (pandas 3.0.2, NumPy 2.4, SciPy 1.17, scikit-learn 1.8, statsmodels 0.15) and the releases
  current in October 2026 (pandas 3.0.5, NumPy 2.5, SciPy 1.18, scikit-learn 1.9). Every reported number
  agreed except the boosted-trees benchmark in R1, whose predictions shift slightly because scikit-learn
  1.9 bins weighted data differently. Two settings keep the run fast under the newer versions: the trees
  are capped at 32 bins (scikit-learn 1.9 computes a weighted percentile for every bin edge, which made
  each fit about 50 times slower at the default 255), and each maths library runs on one thread (extra
  threads only spin and compete on models this small; on a two-core machine a full run was still in the
  prediction step after 9 minutes without the limit, and finished in 5 with it).

**Calibration of R2** (TWFE cumulative coefficient Σβ; Poisson PML, cluster-robust *t*(G − 1) intervals):

| series (planted Σβ) | effects ×1: mean estimate | coverage | rejects 0 | effects ×5: mean estimate | coverage | rejects 0 |
|---|---|---|---|---|---|---|
| *E. coli* COCA ~ urinary agents (0.40 / 2.0) | 0.41 | 93% | 23% | 2.12 | 100% | 100% |
| MSSA COCA ~ flucloxacillin (0.30 / 1.5) | 0.29 | 93% | 10% | 1.39 | 100% | 73% |
| *P. aeruginosa* ~ fluoroquinolones (0.50 / 2.5) | 0.47 | 93% | 27% | 2.53 | 93% | 100% |
| *C. difficile* COCA ~ 4C, lags 0–3 (0.60 / 3.0) | 0.66 | 93% | 33% | 3.05 | 87% | 100% |
| *Klebsiella* COCA ~ urinary agents (null) | −0.05 | 97% | 3% | −0.04 | 87% | 13% |
| MRSA ~ fluoroquinolones (null) | 0.07 | 100% | 0% | −0.02 | 100% | 0% |
| hospital-onset contrasts, 5 nulls | −0.00 to 0.21 | 90–93% | 7–10% | −0.01 to 0.45 | 80–100% | 0–20% |

30 synthetic datasets at realistic effect sizes and 15 at fivefold effects; 29 outcome months, 42 units.
Estimates centre on the truth: across the 24 series, the mean estimate missed the truth by more than two
Monte Carlo standard errors only once (a null hospital-onset *Klebsiella* series in the fivefold set, mean
0.45 over 15 datasets). Average coverage is about 93.5% against a nominal 95%, the usual slight shortfall
of cluster-robust intervals with 42 clusters, so the notebook also reports pairs-cluster-bootstrap
intervals for the primary hypotheses.

**Other checks.**

* **R1 follows the lag structure.** With effects ×5, a lag-0 effect gives significant same-month skill
  for the hypothesis exposure (+3.6 to +6.6%) that falls to about zero one month ahead. The lag-1
  *C. difficile* effect gives skill at both horizons (+7.5%, +8.6%). Nulls stay at about 0%.
* **R3's built-in check passed.** *C. difficile* vs vancomycin/fidaxomicin, whose prescribing was made to
  respond to cases, was called "infections → prescribing" in 30/30 datasets at realistic effects and 15/15
  at fivefold effects. A spurious forward call at p < 0.05 occurred in 4/30 and 1/15, so the test is
  slightly liberal; it is reported as descriptive and BH-corrected.
* **R5 got the sign right but not always the size.** Against a planted +7.9% per 10% more macrolide
  prescribing, two test datasets without a pathogen collapse in the window gave +7.7% (95% CI +4.5 to
  +11.0) and +11.6% (+8.3 to +15.0); the second interval misses the truth. With a collapse and rebound
  inside the window, the estimate was +46.5%.

## Findings from testing that shape interpretation

1. **Out-of-sample prediction is a low-power test at ICB-month level.** Prescribing anomalies (what is
   left after ICB, season and trend) vary by about 4% on the log scale, while monthly counts carry
   13–35% Poisson noise plus overdispersion. A true elasticity of 0.4 then caps the achievable gain at
   under 1% of deviance. A null R1 is not evidence of no association; R2 is far more sensitive, and the
   national-level skill column is more informative than unit-level skill.
2. **R2 has modest power on API data alone.** At realistic effect sizes and 29 months, the chance of
   detecting a planted effect was 10–33%. With 53 months (adding a supplement), intervals were about
   40–65% narrower and both *E. coli* ~ urinary agents and *C. difficile* ~ 4C were detected. Adding the
   GOV.UK history is the single most useful improvement.
3. **R4 will almost certainly have a weak instrument.** Your CID volume table found the intensity effect on
   fluoroquinolone *items* to be −3.0% per pp (95% CI −8.1 to +2.5; wild p = 0.27). The restriction moved
   share, not volume. Re-estimated here, F = 1.5. Report the reduced form as an intention-to-treat
   contrast and do not quote the IV.
4. **R5 is a check of co-movement, not an elasticity.** A national series cannot separate the post-pandemic
   return of *Mycoplasma* from the recovery of prescribing, and its HAC intervals can be too narrow.
5. **The April 2026 ICB reorganisation** (42 → 36 ICBs, with Frimley, Hertfordshire and West Essex, and
   Suffolk and North East Essex split) is handled by grouping ICBs into units that both sources cover
   identically. Codes are from the ONS *ICB (April 2023)* and *ICB (April 2026)* names-and-codes files.

## Troubleshooting

| message | action |
|---|---|
| `Strata that onset_of() cannot map: [...]` | the API uses new onset labels: extend `onset_of()` in Section 4 |
| `Geographies that cannot be resolved to an ICB` | add `{"API name": "ODS code"}` to `MANUAL_GEO_MAP` |
| `<organism> NOT FOUND` | compare the printed sub-themes with `ORGANISMS[...]["topic"]` patterns |
| `Units with prescribing but no outcome data` | inspect the harmonisation table; `ALLOW_UNMATCHED_UNITS = True` drops them |
| `Conflicting values for the same geography, month and stratum` | the metric has another breakdown (age, sex): filter it in `parse_records()` |
| HTTP 429 / 5xx | rerun: retries back off, and completed requests stay cached |

## Data sources

UKHSA data dashboard API (mandatory HCAI surveillance; *Mycoplasma pneumoniae* laboratory reports), Open
Government Licence v3.0. ONS Integrated Care Boards names and codes, April 2023 and April 2026 (OGL).
NHSBSA Prescription Cost Analysis, as in the CID pipeline.
