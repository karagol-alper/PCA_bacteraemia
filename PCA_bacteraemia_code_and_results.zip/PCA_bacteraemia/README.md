# Primary-care antibiotic prescribing and bacterial infection: code and results

Code and results for *Does Primary-Care Antibiotic Prescribing Predict Bacteraemia and Clostridioides
difficile Infection? An Ecological Study of 42 English Integrated Care Boards* (Karagol A, Karagol T,
Allen V, Norton S, Russell M, Galloway JB; manuscript in preparation).

The analysis links monthly primary-care antibacterial dispensing (NHS Business Services Authority,
Prescription Cost Analysis) to mandatory surveillance of bacteraemia and *C. difficile* infection (UK
Health Security Agency) for 42 integrated care boards (ICBs), December 2023 to December 2025. It asks
whether prescribing improves out-of-sample predictions of infection counts (R1), estimates six
pre-specified organism–drug associations and an exploratory grid (R2), tests which series moves first
(R3), checks whether a policy-instrument design is estimable (R4), and uses national *Mycoplasma
pneumoniae* and invasive group A streptococcal series as positive controls (R5).

## Contents

| Path | What it is |
|---|---|
| `reverse_prescribing_to_bacteria.ipynb` | The analysis: downloads, quality control, R1 to R5, every table and figure |
| `make_synthetic_ukhsa_test_data.py` | Synthetic outcome data with planted effects, for testing the pipeline offline |
| `recompute_r1_intervals.py` | Rebuilds the prediction-skill table from saved predictions (see below) |
| `README_reverse_analysis.md` | Detailed notes: design, settings, validation, fixes after the first run, troubleshooting |
| `outputs_reverse/` | The results reported in the manuscript, with the cached input data |

### Results in `outputs_reverse/`

| File | Manuscript |
|---|---|
| `table_m1_cases.csv` | Table 1 |
| `table_r2_primary_hypotheses.csv` | Table 2 |
| `figures/figure_r0_national_series` (.png, .pdf) | Figure 1 |
| `figures/figure_r1_prediction_skill` | Figure 2 |
| `figures/figure_r2_primary_forest` | Figure 3 |
| `figures/figure_r5_national_controls` | Figure 4 |
| `table_m_s1_exposures.csv` | Supplementary Table 1 |
| `table_m_s2_validation.csv` | Supplementary Table 2 |
| `table_r1_prediction_skill.csv` | Supplementary Table 3 |
| `table_r2_exploratory_grid.csv` | Supplementary Table 4 |
| `table_r3_granger_bidirectional.csv` | Supplementary Table 5 |
| `table_r5_national_controls.csv` | Supplementary Table 6 |
| `figures/figure_r1_national_nowcasts` | Supplementary Figure 1 |
| `figures/figure_r2_exploratory_grid` | Supplementary Figure 2 |
| `figures/figure_r3_direction` | Supplementary Figure 3 |

Also in the folder: `all_tables_reverse.xlsx` (every table in one workbook), `results_summary_reverse.txt`
(the main results in plain text), `r0_outcome_download_audit.csv` and `r0_geography_harmonisation.csv`
(what the interface returned and how ICBs were matched), `r0_outcome_descriptives.csv`,
`r0_ukhsa_hcai_by_geography_month.csv` (parsed outcome counts), `r1_out_of_sample_predictions.csv.gz`
(every out-of-sample prediction) and `models_not_estimated_reverse.csv` (the R4 models the estimability
guard refused).

Supplementary Table 7 is not produced by a single run: it summarises the pipeline's estimates on 45
synthetic datasets from `make_synthetic_ukhsa_test_data.py` (30 at realistic effect sizes, 15 at fivefold
effects), tabulated in `README_reverse_analysis.md`.

### Cached inputs

* `outputs_reverse/extract_bnf0501.csv.gz`: oral systemic antibacterials (BNF 5.1) from the 60 monthly
  Prescription Cost Analysis files, January 2021 to December 2025.
* `outputs_reverse/ukhsa_api_cache/`: the 330 responses from the UKHSA data dashboard interface,
  downloaded on 9 October 2026.

## Reproducing the results

1. Keep the notebook next to `outputs_reverse/`, as in this folder. In Google Colab the first cell mounts
   Google Drive and moves to `/content/drive/MyDrive/KCL/Drug/`; change that path to your folder.
   Elsewhere the cell does nothing.
2. Optionally set the environment variable `REV_OFFLINE=1` (in Colab, run `%env REV_OFFLINE=1` first) so
   that the notebook uses the cached responses only and never contacts the interface.
3. Run all cells (about 5 minutes on two cores). With no raw `pca_*.csv` files in the folder, the notebook
   reads the cached prescribing extract. It overwrites the files in `outputs_reverse/`.

An independent re-run on these cached inputs (Python 3.13; pandas 3.0.5, NumPy 2.5.3, SciPy 1.18.1,
statsmodels 0.15.0, scikit-learn 1.9.1) reproduced every data table exactly, and every association,
Granger and positive-control estimate to within 10⁻⁸. Prediction estimates were identical except for the
gradient-boosted benchmark, whose fits depend on the scikit-learn version. Without the cache, the notebook
downloads the current series, which UKHSA may have revised since 9 October 2026.

## Prediction-skill intervals

The notebook seeds each skill bootstrap with text that includes the forecast horizon. In the reported run,
pandas returned the horizon as a NumPy integer, whose text differs from that of a plain integer, so the
intervals depended on the pandas version. The notebook now converts the horizon to a plain integer. The
intervals in `table_r1_prediction_skill.csv`, `all_tables_reverse.xlsx` and `results_summary_reverse.txt`
were recomputed with the corrected seed from the run's saved predictions:

    python recompute_r1_intervals.py outputs_reverse/r1_out_of_sample_predictions.csv.gz r1.csv

The rest of each file is as the run wrote it. Point estimates are unaffected, and the same 11 of 100
comparisons have intervals above zero, so Figure 2 is unchanged. Adding `--legacy-seed` reproduces the
run's original intervals.

## Data sources

* NHS Business Services Authority. Prescription Cost Analysis (PCA) Monthly Administrative Data.
  https://opendata.nhsbsa.net/dataset/prescription-cost-analysis-pca-monthly-data
* UK Health Security Agency. UKHSA data dashboard: mandatory surveillance of bacteraemia and
  *C. difficile* infection by ICB; national *M. pneumoniae* laboratory reports and invasive group A
  streptococcal notifications. https://ukhsa-dashboard.data.gov.uk/access-our-data
* Office for National Statistics. Integrated Care Boards (April 2023) and (April 2026) Names and Codes in
  EN (codes embedded in the notebook).

Contains public sector information licensed under the Open Government Licence v3.0.
