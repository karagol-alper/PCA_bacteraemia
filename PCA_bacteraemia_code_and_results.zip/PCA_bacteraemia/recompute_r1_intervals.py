"""Rebuild the R1 prediction-skill table from the saved out-of-sample predictions.

The notebook (Section 7) seeds each skill bootstrap from text that includes the forecast horizon. With
pandas below 3.0 the horizon arrives as a NumPy integer, whose text differs from a plain integer, so the
seed - and the bootstrap intervals - depended on the pandas version. The notebook now converts the horizon
to a plain integer. The run reported in the manuscript was made before that fix, so its intervals were
recomputed with this script from that run's saved predictions; the point estimates do not depend on the
seed and are unchanged.

usage:
  python recompute_r1_intervals.py outputs_reverse/r1_out_of_sample_predictions.csv.gz recomputed_r1.csv
  python recompute_r1_intervals.py ... --legacy-seed     # the seed text of the original run (NumPy integer)
"""
import argparse
import zlib

import numpy as np
import pandas as pd

RANDOM_SEED, N_BOOT_SKILL, SKILL_BLOCK = 20240122, 4999, 3          # as in the notebook
SHORT = {"ECOLI": "E. coli", "KLEB": "Klebsiella spp.", "PSA": "P. aeruginosa", "MSSA": "MSSA", "MRSA": "MRSA",
         "CDI": "C. difficile"}


def _seed(tag):
    return RANDOM_SEED + zlib.crc32(str(tag).encode()) % 100000


def poisson_dev(y, mu):
    y, mu = np.asarray(y, float), np.maximum(np.asarray(mu, float), 1e-9)
    with np.errstate(divide="ignore", invalid="ignore"):
        t = np.where(y > 0, y * np.log(np.where(y > 0, y, 1.0) / mu), 0.0)
    return 2 * (t - (y - mu))


def block_skill(dm, db, B, block, seed):
    """Moving-block bootstrap of 1 - sum(model deviance) / sum(baseline deviance) over test months."""
    n = len(dm)
    rng = np.random.default_rng(seed)
    b = min(block, n)
    starts = rng.integers(0, n - b + 1, size=(B, int(np.ceil(n / b))))
    idx = (starts[:, :, None] + np.arange(b)[None, None, :]).reshape(B, -1)[:, :n]
    return 1 - dm[idx].sum(1) / db[idx].sum(1)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("predictions")
    ap.add_argument("out_csv")
    ap.add_argument("--legacy-seed", action="store_true", help="seed text with a NumPy integer horizon")
    args = ap.parse_args()

    pred = pd.read_csv(args.predictions)
    models = list(dict.fromkeys(pred.model))
    rows = []
    for (org, onset, h), g in pred.groupby(["org", "onset", "h"], sort=False):
        hk = np.int64(h) if args.legacy_seed else int(h)
        base = g[g.model == "Baseline"].set_index(["UNIT", "YEAR_MONTH"])
        for model in models:
            gm = g[g.model == model].set_index(["UNIT", "YEAR_MONTH"])
            gb = base.reindex(gm.index)
            ok = (gm.yhat.notna() & gb.yhat.notna()).to_numpy()
            gm, gb = gm[ok], gb[ok]
            if gm.empty:
                continue
            pm = pd.DataFrame({"dm": gm.dev.groupby(level="YEAR_MONTH").sum(),
                               "db": gb.dev.groupby(level="YEAR_MONTH").sum()}).sort_index()
            skill = 1 - pm.dm.sum() / pm.db.sum()
            bs = (block_skill(pm.dm.to_numpy(), pm.db.to_numpy(), N_BOOT_SKILL, SKILL_BLOCK,
                              _seed((org, onset, hk, model))) if model != "Baseline" else None)
            nat = pd.DataFrame({"y": gm.y.groupby(level="YEAR_MONTH").sum(),
                                "p": gm.yhat.groupby(level="YEAR_MONTH").sum(),
                                "b": gb.yhat.groupby(level="YEAR_MONTH").sum()})
            nat_skill = 1 - poisson_dev(nat.y, nat.p).sum() / poisson_dev(nat.y, nat.b).sum()
            rows.append(dict(organism=SHORT[org], org=org, onset=onset, horizon=int(h), model=model,
                             test_months=len(pm), test_unit_months=len(gm), mean_poisson_deviance=gm.dev.mean(),
                             MAE=(gm.y - gm.yhat).abs().mean(),
                             national_MAPE_pct=100 * ((nat.p - nat.y).abs() / nat.y.clip(lower=1)).mean(),
                             national_skill_pct=100 * nat_skill if model != "Baseline" else np.nan,
                             skill_pct=100 * skill,
                             skill_low=100 * np.percentile(bs, 2.5) if bs is not None else np.nan,
                             skill_high=100 * np.percentile(bs, 97.5) if bs is not None else np.nan,
                             p_no_gain=float((bs <= 0).mean()) if bs is not None else np.nan))
    pd.DataFrame(rows).to_csv(args.out_csv, index=False)
    print("wrote %s: %d rows" % (args.out_csv, len(rows)))


if __name__ == "__main__":
    main()
